# Instalaci�n

Para instalar el paquete de idioma Espa�ol a SugarCR descarga el archivo ZIP del �ltimo de tags (Releases) de este repositorio, descompr�melo y selecciona todos los archivos (bajar un directorio en el zip) para crear el zip SugarCrm-6.5-SpanishLanguagePack-$VERSION.zip y s�belo a tu SugarCRM mediante "Module Loader". Por alguna extr�a raz�n al descargar el Tag GitHub le a�ade un directorio al zip dejando el codigo un nivel hacia el interior.

# �C�mo colaborar a este proyecto?

IMPORTANTE: Se usa GitFlow.

1. Clona el repositorio y opera en el branch develop ( git checkout develop) y trabaja en tu copia de trabajo integrando tus feature-branches hacia develop.

2. Sube los cambios empujando develop hacia el origin develop y avisa al administrador para integrar el commit hacia el master y generar cada cierto tiempo un release tag.

NOTA: Los tag release usan la siguiente nomenclatura: VERSION-DE-SUGAR-CRM-VERSION-DEL-LENGUAJE: Ejemplo: SugarCrm-6.5-SpanishLanguagePack-1.2.1     N�meros de Release: Mayor.Menor.Hotfix

CR�DITOS: pokoli es el creador de los archivos traducidos.
