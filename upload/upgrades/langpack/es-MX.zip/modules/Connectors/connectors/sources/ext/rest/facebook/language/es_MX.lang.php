<?php

    if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

    $connector_strings = array (
        //Vardef labels
        'LBL_LICENSING_INFO' => '<table border="0" cellspacing="1"><tr><th valign="top" width="35%" class="dataLabel">Información de la Aplicación de Facebook</th></tr>
                                    <tr><td width="35%" class="dataLabel">Ud. necesita crear una aplicación de Facebook, obtenga una en <a href=https://developers.facebook.com/?ref=pf">here</a>  </td></tr></table>',

        //Configuration labels
        'appid' => 'ID de Facebook App ',
        'secret' => 'Secreto de la aplicación de Facebook ',
    );

?>