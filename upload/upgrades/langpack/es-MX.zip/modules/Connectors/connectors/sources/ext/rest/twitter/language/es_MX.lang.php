<?php

    if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

    $connector_strings = array (
        //Vardef labels
        'LBL_LICENSING_INFO' => '<table border="0" cellspacing="1"><tr><th valign="top" width="35%" class="dataLabel">Información de la aplicación de Twitter </th></tr>
                                    <tr><td width="35%" class="dataLabel">Ud. necesita crear una cuente de desarrollador de Twitter y una aplicación <a href=https://dev.twitter.com/> Registrarse</a></td></tr></table>',
        //Configuration labels
        'consumer_key' => 'Clave de usuario',
        'consumer_secret' => 'Cadena secreta',
    );


?>
