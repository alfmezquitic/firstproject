<?php
$module_name = 'admin_Cuenta_TipoMargen';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '10%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'JL_PORCENTAJECOBRO' => 
  array (
    'type' => 'decimal',
    'default' => true,
    'label' => 'LBL_JL_PORCENTAJECOBRO',
    'width' => '10%',
  ),
  'JL_PORCENTAJECOBROFIJO' => 
  array (
    'type' => 'decimal',
    'default' => true,
    'label' => 'LBL_JL_PORCENTAJECOBROFIJO',
    'width' => '10%',
  ),
);
?>
